import uproot
import pandas
import sys
import os

def analyze_root_file(file_path):
    """
    Opens a ROOT file, lists all ntuples (TTree objects),
    and prints the number of entries in each.
    """
    if not os.path.exists(file_path):
        print(f"Error: File not found at '{file_path}'")
        return

    print(f"Analyzing file: {file_path}\n")

    try:
        with uproot.open(file_path) as file:
            # Get a list of all top-level objects that are TTrees (ntuples)
            tree_names = [key for key, value in file.classnames().items() if value == "TTree"]

            if not tree_names:
                print("No ntuples (TTrees) found in the file.")
                return

            print("Found the following ntuples:")
            for name in tree_names:
                try:
                    tree = file[name]
                    num_entries = tree.num_entries
                    print(f"- Ntuple '{name}': {num_entries} entries")
                except Exception as e:
                    print(f"- Could not read ntuple '{name}': {e}")
            
            print("\n--- Detailed View (SmallDetSummary) ---")
            summary_name = "SmallDetSummary"
            if summary_name in tree_names:
                tree = file[summary_name]
                if tree.num_entries > 0:
                    print(f"Showing first 5 entries of '{summary_name}':")
                    # Convert to pandas DataFrame to display
                    df = tree.arrays(library="pd", entry_stop=5)
                    print(df)
                else:
                    print(f"The '{summary_name}' ntuple exists but is empty.")
            else:
                print(f"The '{summary_name}' ntuple does not exist in the file.")


    except Exception as e:
        print(f"An error occurred while reading the ROOT file: {e}")

if __name__ == "__main__":
    # Default file path, adjust if your output file is named differently
    default_file = "/home/frisoe/Desktop/Root/output_SP_filterOff_1000keV_option4_N10k.root"
    
    # Use command line argument if provided, otherwise use default
    root_file_path = sys.argv[1] if len(sys.argv) > 1 else default_file
    
    analyze_root_file(root_file_path)