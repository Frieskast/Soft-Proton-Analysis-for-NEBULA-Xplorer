import os
import re
import glob
import sys
import csv
import uproot
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from collections import defaultdict
import ROOT

ROOT_FILE = "/home/frisoe/Desktop/Root/root/output_DCC_filterOn_1000keV_option4_N1m.root"

# --- filename parsing helpers ---

# Match type (e.g. "DPH")
type_pat = re.compile(r'output_([A-Za-z0-9]+)_filter(?:On|Off)', re.IGNORECASE)

# Match filter state (On or Off)
filter_pat = re.compile(r'_filter(On|Off)', re.IGNORECASE)

# Match energy in keV
energy_pat = re.compile(r'_([0-9]+)keV', re.IGNORECASE)

# Match number of primaries (N...)
N_pat = re.compile(r'_N([0-9]*\.?[0-9]+[kKmM]?)')

def get_scattering_distribution(rootfile, histname="SmallDet;1;Ekin"):
    """"""
    f = ROOT.TFile.Open(rootfile)
    if not f or f.IsZombie():
        raise IOError(f"Could not open {rootfile}")

    h = f.Get(histname)
    if not h:
        raise KeyError(f"Histogram {histname} not found in {rootfile}")

    nbins = h.GetNbinsX()
    bin_edges = np.array([h.GetBinLowEdge(i+1) for i in range(nbins)] + [h.GetXaxis().GetXmax()])
    bin_centers = np.array([h.GetBinCenter(i+1) for i in range(nbins)])
    counts = np.array([h.GetBinContent(i+1) for i in range(nbins)])

    # restrict to 0–90 deg
    mask = (bin_centers >= 0) & (bin_centers <= 90)
    bin_edges = bin_edges[np.where(mask)[0][0] : np.where(mask)[0][-1] + 2]
    bin_centers = bin_centers[mask]
    counts = counts[mask]

    total = np.sum(counts)
    bin_widths = bin_edges[1:] - bin_edges[:-1]
    norm_counts = counts / (total * bin_widths)
    errors = np.sqrt(counts) / (total * bin_widths)
    n_primaries = int(h.GetEntries())

    f.Close()
    return bin_centers, bin_widths, norm_counts, errors, int(total), n_primaries


def parse_angle_energy_from_fname(fname):
    b = os.path.basename(fname)
    m = energy_pat.search(b)
    if not m:
        return None, None
    angle = float(m.group(1))
    energy = int(m.group(2))
    return energy, angle


# --- user params ---
root_file = sys.argv[1] if len(sys.argv) > 1 else "/home/frisoe/Desktop/Root/root/output_DCC_filterOn_1000keV_option4_N1m.root"
figures_dir = os.path.join(os.path.dirname(__file__), "figures")
os.makedirs(figures_dir, exist_ok=True)

plt.rcParams.update({
    "font.size": 12,
    "axes.labelsize": 13,
    "axes.titlesize": 14,
    "legend.fontsize": 11,
    "lines.linewidth": 1.5,
})

def load_tree(tree, cols):
    try:
        arrs = tree.arrays(cols, library="np")
    except Exception:
        return None
    return arrs

def group_indices_by_event(event_ids):
    # returns list of arrays of indices grouped by event id
    order = np.argsort(event_ids)
    sorted_e = event_ids[order]
    if sorted_e.size == 0:
        return []
    breaks = np.where(np.diff(sorted_e) != 0)[0] + 1
    groups = np.split(order, breaks)
    return groups

# open file
f = uproot.open(root_file)
print("Opened:", root_file)
keys = list(f.keys())
print("ROOT keys:", keys)

# ---------------------------------------------------------------------
# SmallDet: per-step entries (x,y,z,Ekin,EventID,trajectory,...)
if "SmallDet;1" in keys or "SmallDet" in keys:
    tname = "SmallDet;1" if "SmallDet;1" in keys else "SmallDet"
    tree = f[tname]
    cols = ["x", "y", "z", "Ekin", "EventID"]
    data = load_tree(tree, cols)
    if data is not None:
        x = np.asarray(data["x"])
        y = np.asarray(data["y"])
        z = np.asarray(data["z"])
        Ekin = np.asarray(data["Ekin"])
        evt = np.asarray(data["EventID"]).astype(int)
        print("SmallDet entries:", x.size, "unique events:", np.unique(evt).size)

        groups = group_indices_by_event(evt)

        entry_x = []
        entry_y = []
        entry_z = []
        entry_E = []
        exit_E = []
        loss = []

        # For each event choose entry as the step with maximum Ekin inside the detector,
        # exit as the step with minimum Ekin (or last step); compute loss = entry - exit.
        for g in groups:
            if g.size == 0:
                continue
            gE = Ekin[g]
            gi_entry = g[np.argmax(gE)]
            gi_exit = g[np.argmin(gE)]
            entry_x.append(x[gi_entry])
            entry_y.append(y[gi_entry])
            entry_z.append(z[gi_entry])
            entry_E.append(Ekin[gi_entry])
            exit_E.append(Ekin[gi_exit])
            loss.append(Ekin[gi_entry] - Ekin[gi_exit])

        entry_x = np.array(entry_x)
        entry_y = np.array(entry_y)
        entry_z = np.array(entry_z)
        entry_E = np.array(entry_E)
        exit_E = np.array(exit_E)
        loss = np.array(loss)

        # 2D heatmap of entry positions
        plt.figure(figsize=(7,6))
        nbins = 120
        h, xedges, yedges, img = plt.hist2d(entry_x, entry_y, bins=nbins, cmap="viridis")
        plt.colorbar(label="counts")
        plt.xlabel("x (mm)")
        plt.ylabel("y (mm)")
        plt.title("SmallDet entry position density")
        out = os.path.join(figures_dir, "smallDet_entry_xy_hist2d.png")
        plt.savefig(out, dpi=150, bbox_inches="tight")
        plt.close()
        print("Saved:", out)

        # scatter of entry positions colored by energy loss
        plt.figure(figsize=(7,6))
        sc = plt.scatter(entry_x, entry_y, c=loss, cmap="inferno", s=18, edgecolor='none')
        plt.colorbar(sc, label="E_loss (keV)")
        plt.xlabel("x (mm)")
        plt.ylabel("y (mm)")
        plt.title("SmallDet entry positions colored by energy loss")
        out = os.path.join(figures_dir, "smallDet_entry_xy_loss.png")
        plt.savefig(out, dpi=150, bbox_inches="tight")
        plt.close()
        print("Saved:", out)

        # histogram of energy loss per event
        plt.figure(figsize=(6,4))
        plt.hist(loss, bins=80, histtype='stepfilled', alpha=0.8)
        plt.xlabel("Energy loss in SmallDet (keV)")
        plt.ylabel("Events")
        plt.title("Energy loss distribution (SmallDet)")
        out = os.path.join(figures_dir, "smallDet_loss_hist.png")
        plt.savefig(out, dpi=150, bbox_inches="tight")
        plt.close()
        print("Saved:", out)

        # 3D scatter of all steps colored by Ekin (subsample if too many points)
        n_points = x.size
        max_pts = 200000
        stride = max(1, n_points // max_pts)
        fig = plt.figure(figsize=(8,6))
        ax = fig.add_subplot(111, projection='3d')
        ax.scatter(x[::stride], y[::stride], z[::stride], c=Ekin[::stride], cmap="plasma", s=3)
        ax.set_xlabel("x (mm)")
        ax.set_ylabel("y (mm)")
        ax.set_zlabel("z (mm)")
        ax.set_title("SmallDet steps colored by Ekin (keV)")
        out = os.path.join(figures_dir, "smallDet_steps_3d.png")
        plt.savefig(out, dpi=150, bbox_inches="tight")
        plt.close()
        print("Saved:", out)
    else:
        print("SmallDet tree exists but could not load columns", cols)
else:
    print("SmallDet tree not found in ROOT file.")

# ---------------------------------------------------------------------
# FocalDet plotting
if "FocalDet;1" in keys or "FocalDet" in keys:
    tname = "FocalDet;1" if "FocalDet;1" in keys else "FocalDet"
    tree = f[tname]
    cols = ["x", "y", "z", "Ekin", "EventID"]
    data = load_tree(tree, cols)
    if data is not None:
        fx = np.asarray(data["x"])
        fy = np.asarray(data["y"])
        fE = np.asarray(data["Ekin"])
        print("FocalDet entries:", fx.size)
        plt.figure(figsize=(7,6))
        plt.scatter(fx, fy, c=fE, s=8, cmap="viridis", edgecolor='none')
        plt.colorbar(label="Ekin (keV)")
        plt.xlabel("x (mm)")
        plt.ylabel("y (mm)")
        plt.title("Focal plane hits colored by Ekin")
        out = os.path.join(figures_dir, "focal_plane_xy_Ekin.png")
        plt.savefig(out, dpi=150, bbox_inches="tight")
        plt.close()
        print("Saved:", out)
    else:
        print("FocalDet tree exists but could not load columns", cols)
else:
    print("FocalDet tree not found in ROOT file.")

# ---------------------------------------------------------------------
# TID ntuple
if "TID;1" in keys or "TID" in keys:
    tname = "TID;1" if "TID;1" in keys else "TID"
    tree = f[tname]
    cols = ["TID_krad_det", "TID_krad_focal"]
    data = load_tree(tree, cols)
    if data is not None:
        tid_det = np.asarray(data["TID_krad_det"])
        tid_focal = np.asarray(data["TID_krad_focal"])
        plt.figure(figsize=(6,4))
        plt.plot(tid_det, marker='o', linestyle='-', label='det')
        plt.plot(tid_focal, marker='s', linestyle='-', label='focal')
        plt.xlabel("Entry index")
        plt.ylabel("TID (krad)")
        plt.legend()
        plt.title("TID run-level values")
        out = os.path.join(figures_dir, "TID_values.png")
        plt.savefig(out, dpi=150, bbox_inches="tight")
        plt.close()
        print("Saved:", out)
    else:
        print("TID tree exists but could not load columns", cols)
else:
    print("TID tree not found in ROOT file.")

f.close()



